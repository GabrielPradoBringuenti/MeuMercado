<?php

	$nomeProduto  = $_POST ["nomeProduto"];
	$tipoProduto  = $_POST ["tipoProduto"];
	$valorProduto = $_POST ["valorProduto"]; 

	echo $nomeProduto;


?>