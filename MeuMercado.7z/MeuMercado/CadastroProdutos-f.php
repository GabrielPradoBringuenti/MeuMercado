<html>
	<head>
		<title>Cadastro de Produtos</title>
	</head>
	<body>
	<table>
		<form name="frmCadastroProdutos" action="CadastroProdutos-p.php" method="post">
		<table align="center">	
			 <tr>
				<td><label>Nome</label></td>
				<td><input type="text" name="nomeProduto" id="nomeProduto" placeholder="Digite o nome do Produto"/></td>
			</tr>
			<tr>
				<td><label>Tipo</label></td>
				<td><input type="text" name="tipoProduto" id="tipoProduto" placeholder="Digite o Tipo do Produto"/></td>
			</tr>
			<tr>
				<td><label>Valor</label></td>
				<td><input type="double" name="valorProduto" id="valorProduto" placeholder="Digite o valor do Produto"/></td>
			</tr>
			<table align="center">
				<tr>
					<td><input type="submit" name="Cadastrar"/></td>
					<td><input type="reset" name="Cancelar" value="Cancelar"/></td>
				</tr>
			</table>
		</form>
	</table>
	</body>
</html>


